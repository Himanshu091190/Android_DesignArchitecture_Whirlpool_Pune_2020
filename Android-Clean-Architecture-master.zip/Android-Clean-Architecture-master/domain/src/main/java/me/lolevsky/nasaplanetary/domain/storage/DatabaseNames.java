package me.lolevsky.nasaplanetary.domain.storage;

public interface DatabaseNames {
    final static String TABLE_COMMENTS = "table_comments";
}
