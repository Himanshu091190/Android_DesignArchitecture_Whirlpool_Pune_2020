package me.lolevsky.nasaplanetary.domain.entety;

public class MainScreenEntity {
    String name;

    public MainScreenEntity(String name){
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
