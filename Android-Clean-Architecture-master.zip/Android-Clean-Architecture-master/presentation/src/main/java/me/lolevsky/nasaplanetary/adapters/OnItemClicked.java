package me.lolevsky.nasaplanetary.adapters;

public interface OnItemClicked {
    void onItemClicked(int position);
}
