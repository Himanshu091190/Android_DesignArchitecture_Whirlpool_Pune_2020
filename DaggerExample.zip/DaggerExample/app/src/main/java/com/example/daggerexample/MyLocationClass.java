package com.example.daggerexample;

import android.content.Context;
import android.location.LocationManager;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

import static android.content.Context.LOCATION_SERVICE;

@Module
public class MyLocationClass {

    Context ctx;
    public MyLocationClass(Context ctx) {
        this.ctx = ctx;
    }

    @Singleton
    @Provides
    public LocationManager providegetLocation() {
        return (LocationManager) ctx.getSystemService(LOCATION_SERVICE);
    }
}
