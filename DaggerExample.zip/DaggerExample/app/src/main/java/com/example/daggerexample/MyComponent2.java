package com.example.daggerexample;

import javax.inject.Singleton;
import dagger.Component;

@Singleton
@Component(modules = {MyLocationClass.class})
public interface MyComponent2 {
    void inject(Main2Activity activity);
}