package com.example.daggerexample;

import javax.inject.Inject;

public class User {

    String username;

    @Inject
    public User() {
    }

    public boolean validateUserName(String username) {
        if(username.equals("himanshu"))
            return true;
        else
            return false;
    }

}
