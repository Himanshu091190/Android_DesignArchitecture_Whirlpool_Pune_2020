package com.example.daggerexample;

import android.location.LocationManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import javax.inject.Inject;

public class Main2Activity extends AppCompatActivity {

    MyComponent2 mycomp2;
    @Inject
    LocationManager mLocationManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        mycomp2 = DaggerMyComponent2.builder().myLocationClass(new MyLocationClass(this)).build();
        mycomp2.inject(this);
    }
}
